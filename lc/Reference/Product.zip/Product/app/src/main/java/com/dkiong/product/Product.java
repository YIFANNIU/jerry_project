package com.dkiong.product;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Product extends HashMap<String, String> {
    final static String baseurl = "http://192.168.56.101/holiday";

    public Product(String id, String name, double price, int quantity) {
        put("id", id);
        put("name", name);
        put("price", Double.toString(price));
        put("quantity", Integer.toString(quantity));
    }

    public static List<String> list() {
        List<String> list = new ArrayList<String>();
        JSONArray a = JSONParser.getJSONArrayFromUrl(String.format("%s/Service.svc/List", baseurl));
        try {
            for (int i =0; i<a.length(); i++) {
                String b = a.getString(i);
                list.add(b);
            }
        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }
        return(list);
    }

    public static Product getProduct(String id) {
        Product p = null;
        try {
            JSONObject a = JSONParser.getJSONFromUrl(String.format("%s/Service.svc/GetProduct/%s", baseurl, id));
            p = new Product(a.getString("Id"), a.getString("Name"), a.getDouble("Price"), a.getInt("Quantity"));
        } catch (Exception e) {
            Log.e("getProduct", "JSON error");
        }
        return p;
    }

    public static void updateProduct(String id, String name, String price, String quantity) {
        try {
            JSONObject customer = new JSONObject();
            customer.put("Id", id);
            customer.put("Name", name);
            customer.put("Price", price);
            customer.put("Quantity", quantity);
            String json = customer.toString();
            String result = JSONParser.postStream(
                    String.format("%s/Service.svc/UpdateProduct", baseurl),
                    json);
        } catch (Exception e) {
            Log.e("updateProduct", "JSON error");
        }
    }
}