package com.dkiong.product;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;


public class DetailsActivity extends ActionBarActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Button b = (Button) findViewById(R.id.button);
        b.setOnClickListener(this);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (intent.hasExtra("ID")) {
            String id = bundle.getString("ID");
            new AsyncTask<String, Void, Product>() {
                @Override
                protected Product doInBackground(String... params) {
                    Product p = Product.getProduct(params[0]);
                    return p;
                }
                @Override
                protected void onPostExecute(Product p) {
                    EditText e = (EditText) findViewById(R.id.editText);
                    e.setText(p.get("id"));
                    e = (EditText) findViewById(R.id.editText2);
                    e.setText(p.get("name"));
                    e = (EditText) findViewById(R.id.editText3);
                    e.setText(p.get("price"));
                    e = (EditText) findViewById(R.id.editText4);
                    e.setText(p.get("quantity"));
                }
            }.execute(id);

        }
    }

    @Override
    public void onClick(View v) {
        EditText e = (EditText) findViewById(R.id.editText);
        String s1 = e.getText().toString();
        e = (EditText) findViewById(R.id.editText2);
        String s2 = e.getText().toString();
        e = (EditText) findViewById(R.id.editText3);
        String s3 = e.getText().toString();
        e = (EditText) findViewById(R.id.editText4);
        String s4 = e.getText().toString();

        new AsyncTask<String, Void, Void>() {
            @Override
            protected Void doInBackground(String... params) {
                Product.updateProduct(params[0], params[1], params[2], params[3]);
                return null;
            }
            @Override
            protected void onPostExecute(Void v) {
                setResult(RESULT_OK);
                finish();
            }
        }.execute(s1, s2, s3, s4);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
