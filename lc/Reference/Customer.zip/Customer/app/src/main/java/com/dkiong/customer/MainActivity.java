package com.dkiong.customer;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;


public class MainActivity extends ActionBarActivity implements AdapterView.OnItemClickListener {
    private static final int ACTIVITY_CREATE = 0;
    private static final int ACTIVITY_EDIT = 1;
    private CustomerDbAdapter db;
    private ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(android.R.layout.list_content);
        listView = (ListView) findViewById(android.R.id.list);
        listView.setOnItemClickListener(this);
        db = new CustomerDbAdapter(this);
        db.open();
        fillData();
        registerForContextMenu(listView);
    }

    @Override
    protected void onResume(){
        super.onResume();
        fillData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.insert:
                createCustomer();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete:
                AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
                db.deleteCustomer(info.id);
                fillData();
                return true;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public void onItemClick(AdapterView<?> av, View v, int position, long id) {
        Intent i = new Intent(this, CustomerDetails.class);
        i.putExtra(CustomerDbAdapter.KEY_ROWID, id);
        startActivityForResult(i, ACTIVITY_EDIT);
    }

    private void createCustomer() {
        Intent i = new Intent(this, CustomerDetails.class);
        startActivityForResult(i, ACTIVITY_CREATE);
    }

    private void fillData() {
        Cursor cursor = db.fetchAllCustomers();
        startManagingCursor(cursor);
        String[] from = new String[] { CustomerDbAdapter.KEY_NAME, CustomerDbAdapter.KEY_COMPANY };
        int[] to = new int[] { R.id.textView1, R.id.textView2 };
        // Now create an array adapter and set it to display using our row
        SimpleCursorAdapter notes = new SimpleCursorAdapter(this,
                R.layout.row, cursor, from, to, 0);
        listView.setAdapter(notes);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null)
            db.close();
    }
}
