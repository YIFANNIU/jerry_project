package com.dkiong.customer;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CustomerDetails extends ActionBarActivity {

    private CustomerDbAdapter db;
    private EditText t_name, t_company, t_address, t_creditLimit;
    private Long rowId = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);
        Button b = (Button) findViewById(R.id.button1);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
        t_name = (EditText) findViewById(R.id.edit_name);
        t_company = (EditText) findViewById(R.id.edit_company);
        t_address = (EditText) findViewById(R.id.edit_address);
        t_creditLimit = (EditText) findViewById(R.id.edit_creditlimit);
        db = new CustomerDbAdapter(this);
        db.open();
        toRestore(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        if (extras != null)
            rowId = extras.getLong(CustomerDbAdapter.KEY_ROWID);
        populateFields();
    }

    private void populateFields() {
        if (rowId != null) {
            Cursor customer = db.fetchCustomer(rowId);
            startManagingCursor(customer);
            t_name.setText(customer.getString(customer
                    .getColumnIndexOrThrow(CustomerDbAdapter.KEY_NAME)));
            t_company.setText(customer.getString(customer
                    .getColumnIndexOrThrow(CustomerDbAdapter.KEY_COMPANY)));
            t_address.setText(customer.getString(customer
                    .getColumnIndexOrThrow(CustomerDbAdapter.KEY_ADDRESS)));
            t_creditLimit.setText(Float.toString(customer.getFloat(customer
                    .getColumnIndexOrThrow(CustomerDbAdapter.KEY_CREDITLIMIT))));
        }
    }

    private void saveState() {
        String name = t_name.getText().toString();
        String company = t_company.getText().toString();
        String address = t_address.getText().toString();
        double creditLimit;
        try {
            creditLimit = Double.parseDouble(t_creditLimit.getText().toString());
        } catch (Exception e) {
            creditLimit = 0;
        }
        if (rowId == null) {
            long id = db.createCustomer(name, company, address, creditLimit);
            if (id > 0)
                rowId = id;
        } else
            db.updateCustomer(rowId, name, company, address, creditLimit);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        toSave(outState);
    }

    private void toSave(Bundle outState) {
        outState.putSerializable(CustomerDbAdapter.KEY_ROWID, rowId);
    }

    private void toRestore(Bundle state) {
        if (state != null) {
            rowId = (Long) state.getSerializable(CustomerDbAdapter.KEY_ROWID);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateFields();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null)
            db.close();
    }
}

