package com.dkiong.customer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class CustomerDbAdapter {
    public static final String KEY_ROWID = "_id";
    public static final String KEY_NAME = "Name";
    public static final String KEY_COMPANY = "Company";
    public static final String KEY_ADDRESS = "Address";
    public static final String KEY_CREDITLIMIT = "CreditLimit";

    private static final String DATABASE_TABLE = "Customer";

    private Context context;
    private SQLiteDatabase database;
    private CustomerDatabaseHelper dbHelper;

    public CustomerDbAdapter(Context context) {
        this.context = context;
    }

    public CustomerDbAdapter open() throws SQLException {
        dbHelper = new CustomerDatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public long createCustomer(String name, String company, String address, double creditLimit) {
        ContentValues initialValues = createContentValues(name, company,
                address, creditLimit);

        return database.insert(DATABASE_TABLE, null, initialValues);
    }

    public boolean updateCustomer(long rowId, String name, String company,
                                  String address, double creditLimit) {
        ContentValues updateValues = createContentValues(name, company,
                address, creditLimit);

        return database.update(DATABASE_TABLE, updateValues, KEY_ROWID + "="
                + rowId, null) > 0;
    }

    public boolean deleteCustomer(long rowId) {
        return database.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
    }

    public Cursor fetchAllCustomers() {
        return database.query(DATABASE_TABLE, new String[] { KEY_ROWID,
                        KEY_NAME, KEY_COMPANY, KEY_ADDRESS, KEY_CREDITLIMIT }, null, null, null,
                null, null);
    }

    public Cursor fetchCustomer(long rowId) throws SQLException {
        Cursor mCursor = database.query(true, DATABASE_TABLE, new String[] {
                        KEY_ROWID, KEY_NAME, KEY_COMPANY, KEY_ADDRESS, KEY_CREDITLIMIT },
                KEY_ROWID + "=?", new String[] { Long.toString(rowId) } , null, null, null, null);
        if (mCursor != null)
            mCursor.moveToFirst();
        return mCursor;
    }

    private ContentValues createContentValues
               (String name, String company,String address, double creditLimit) {
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_COMPANY, company);
        values.put(KEY_ADDRESS, address);
        values.put(KEY_CREDITLIMIT, creditLimit);
        return values;
    }

}