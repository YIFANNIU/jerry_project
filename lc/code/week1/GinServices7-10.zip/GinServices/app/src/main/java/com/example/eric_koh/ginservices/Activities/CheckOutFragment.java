package com.example.eric_koh.ginservices.Activities;


import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver;
import com.example.eric_koh.ginservices.NetWork.NetUtil;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.Tools.UrlManager;

public class CheckOutFragment extends Fragment implements NetBroadcastReceiver.netEventHandler {
    private View view;
    private SharedPreferences sharedPreferences;
    private String storedId;
    private WebView webView;
    ConnectionDetector cd;
    private ImageView imageview;
    private String checkOutUrl = UrlManager.checkOutUrl;
    public Boolean isInternetPresent = false;
    private Boolean isFirstTime = true;

    public CheckOutFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences =this.getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        System.out.println("onCreate");

    }

    @Override
    public void onResume() {
        super.onResume();

        System.out.println("onresume");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_check_out, container, false);
        webView = (WebView)view.findViewById(R.id.webView1);
        imageview=(ImageView)view.findViewById(R.id.internetInfo);


        System.out.println("onCreateView");

        storedId = sharedPreferences.getString("userID", "0");
        System.out.println("========>StoredID:"+storedId);

        if (storedId.equals("0")){
            displayLoginPage();
            getActivity().getFragmentManager().beginTransaction().remove(this).commit();
        }else {
            displayCheckOutPage(storedId);
        }

        return(view);
    }


    protected void displayLoginPage() {
        final String TAG = "LOGIN_FRAG";
        FragmentManager fm = getFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        Fragment frag = new LoginFragment();
        Bundle args = new Bundle();
        args.putString("from", "CheckOut");
        frag.setArguments(args);
//        if (fm.findFragmentByTag(TAG) == null)
//            trans.add(R.id.checkOutFrame, frag, TAG);
//        else
        trans.replace(R.id.checkOutFrame, frag, TAG);
        trans.commit();
    }

    public void  displayCheckOutPage(String storedId){
        if (isFirstTime){
            NetBroadcastReceiver.mListeners.add(this);
            isFirstTime = false;
        }
        cd = new ConnectionDetector(getActivity().getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();
        System.out.println("++++++++++++++++" + isInternetPresent);

        if (isInternetPresent) {
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setBuiltInZoomControls(true);
            if(imageview.getDrawable()!=null){
                imageview.setVisibility(View.INVISIBLE);

            }
            webView.setWebChromeClient(new WebChromeClient() {
                public void onProgressChanged(WebView view, int progress) {
                    //Activity和Webview根据加载程度决定进度条的进度大小
                    //当加载到100%的时候 进度条自动消失
                    // context.setProgress(progress * 100);
                    Log.i("kkkkkkkkkk", "hahhahahahha");
                }
            });

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    // TODO Auto-generated method stub
                    webView.loadUrl(url);
                    return true;
                }

                @Override
                public void onReceivedError(WebView view, int errorCode,
                                            String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    String str = "file:///android_asset/nointernet.png";
                    webView.clearView();
                    webView.getSettings().setUseWideViewPort(true);
                    webView.getSettings().setLoadWithOverviewMode(true);
                    webView.loadUrl(str);
                }
            });
            //webView.loadUrl("http://www.baidu.com");
            webView.loadUrl(String.format(checkOutUrl,storedId));

        } else {
            webView.clearView();
            imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));
            imageview.setVisibility(View.VISIBLE);

        }

    }

//        @Override
//        public boolean onKeyDown(int keyCode, KeyEvent event) {
//            // TODO Auto-generated method stub
//            if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
//                webView.goBack();
//                return true;
//            }
//            return super.getActivity().onKeyDown(keyCode, event);
//        }


    @Override
    public void onNetChange() {
        // TODO Auto-generated method stub
        if (NetUtil.getNetworkState(getActivity()) == NetUtil.NETWORN_NONE) {
            displayCheckOutPage(storedId);
           // imageview.setVisibility(View.VISIBLE);
            Log.i("11111111", "jjjjj");
        }else {
           displayCheckOutPage(storedId);
          //  imageview.setVisibility(View.INVISIBLE);
            //webView.reload();
            Log.i("22222222","jjjjj");
        }
    }





}