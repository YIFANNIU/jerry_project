package com.example.eric_koh.ginservices.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver;
import com.example.eric_koh.ginservices.NetWork.NetUtil;
import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver.netEventHandler;
import com.example.eric_koh.ginservices.Tools.UrlManager;

/**
 * Created by Eric_Koh on 6/4/15.
 */
public class ContactActivity extends ActionBarActivity implements netEventHandler{
    private String storedId;
    private String previousStoredID;

    private WebView webView;
    private ImageView imageview;
    Boolean isInternetPresent = false;
    private SharedPreferences sharedPreferences;
    ConnectionDetector cd;
    private String contactUrl = UrlManager.contactUrl;
    ProgressDialog dialog = null;
    private Menu menuTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        NetBroadcastReceiver.mListeners.add(this);
        webView = (WebView) findViewById(R.id.webView1);
        imageview = (ImageView) findViewById(R.id.internetInfo);
        sharedPreferences =this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        storedId = previousStoredID = sharedPreferences.getString("userID", "0");
        Loginloadurl(storedId);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_my_account_main, menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_my_account_main, menu);
        menuTitle=menu;
        setTitle();

        return super.onCreateOptionsMenu(menu);


    }

    @Override
    public void onResume() {

        Log.i("tttttttttttt","jjjjjjjjj");
        super.onResume();
        storedId = sharedPreferences.getString("userID", "0");
        System.out.println("111111:"+storedId);
        System.out.println("login onresume");
        if(menuTitle!=null){
            setTitle();
        }

       if (previousStoredID != storedId){
           previousStoredID = storedId;
           Loginloadurl(storedId);
       }
    }
    public void setTitle() {


            menuTitle.getItem(0).setTitle(sharedPreferences.getString("userName", ""));


    }
    public void Loginloadurl(String Id){

        cd = new ConnectionDetector(getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();

        // check for Internet status
        if (isInternetPresent) {

            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setBuiltInZoomControls(true);


            if(imageview.getDrawable()!=null){
                imageview.setVisibility(View.INVISIBLE);

            }

            String Url1 =String.format(contactUrl,Id);

            webView.loadUrl(Url1);
            webView.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    // TODO Auto-generated method stub
                    webView.loadUrl(url);
                    return true;
                }
                @Override
                public void onReceivedError(WebView view, int errorCode,
                                            String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    String str = "file:///android_asset/nointernet.png";
                    view.loadUrl(str);
                    Log.i("testtest test ","hhhhhhh");

                }
            });
        } else {

            webView.clearView();
            imageview.setVisibility(View.VISIBLE);
            imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));

        }

    }
  public void loadurl(){

        cd = new ConnectionDetector(getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();

        // check for Internet status
        if (isInternetPresent) {

            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setBuiltInZoomControls(true);
            if(imageview.getDrawable()!=null){
                imageview.setVisibility(View.INVISIBLE);

            }
            String Url =String.format(contactUrl,"0");
            webView.loadUrl(Url);
            webView.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    // TODO Auto-generated method stub
                    webView.loadUrl(url);
                    return true;
                }
                @Override
                public void onReceivedError(WebView view, int errorCode,
                                            String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);

                    String str = "file:///android_asset/nointernet.png";
                    webView.getSettings().setUseWideViewPort(true);
                    webView.getSettings().setLoadWithOverviewMode(true);
                    webView.loadUrl(str);
                    Log.i("testtest test ","hhhhhhh");

                }
            });


        } else {

            webView.clearView();
            imageview.setVisibility(View.VISIBLE);
            imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));

        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public void onNetChange() {
        // TODO Auto-generated method stub
        if (NetUtil.getNetworkState(this) == NetUtil.NETWORN_NONE) {
           // loadurl();
            Loginloadurl(storedId);
            Log.i("33333","jjjjj");
        }else {
          //  loadurl();
            Loginloadurl(storedId);

            Log.i("44444","jjjjj");
        }
    }

}



