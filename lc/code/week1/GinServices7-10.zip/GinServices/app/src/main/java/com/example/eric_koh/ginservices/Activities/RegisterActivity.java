package com.example.eric_koh.ginservices.Activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver;
import com.example.eric_koh.ginservices.NetWork.NetUtil;
import com.example.eric_koh.ginservices.Populator.UserPopulator;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.Tools.UrlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends ActionBarActivity implements NetBroadcastReceiver.netEventHandler {

    private EditText editText_name;
    private EditText editText_email;
    private EditText editText_psw;
    private EditText editText_confirm_psw;
    private CheckBox checkBox_conditions;
    private Button btn_submit;
    private TextView textView_error;
    private String registerUrl = UrlManager.registerApiUrl;
    private UserPopulator userPopulator;
    private String registerOutcome;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private ConnectionDetector cd;
    private Boolean isInternetPresent = false;
    private ImageView imageview;

    private ProgressDialog pd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        this.setTitle("");
        editText_name = (EditText)findViewById(R.id.editText_name);
        editText_email = (EditText)findViewById(R.id.editText_email);
        editText_psw = (EditText)findViewById(R.id.editText_password);
        editText_confirm_psw = (EditText)findViewById(R.id.editText_confirm_password);
        checkBox_conditions = (CheckBox)findViewById(R.id.checkbox_condition);
        btn_submit = (Button)findViewById(R.id.btn_submit);
        textView_error = (TextView)findViewById(R.id.textView_error);


        imageview=(ImageView)findViewById(R.id.internetInfo);
        cd = new ConnectionDetector(this);
        NetBroadcastReceiver.mListeners.add(this);


        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( isInternetPresent = cd.isConnectingToInternet()){
                    validateRegisterInfo();
                }else {
                    imageview.setVisibility(View.VISIBLE);
                    imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));
                    System.out.println("Network Problem");
                }

            }
        });

    }

    private void validateRegisterInfo(){
        String name = editText_name.getText().toString();
        String password = editText_psw.getText().toString().replace(" ", "");
        String confirm_password = editText_confirm_psw.getText().toString().replace(" ", "");
        String email = editText_email.getText().toString().replace(" ", "");

        if (name.equals("")){
            textView_error.setText("Please Enter Full Name!");
        }else if (email.equals("")){
            textView_error.setText("Please Enter Email!");
        }else  if (!isEmail(email)){
            textView_error.setText("Invalid Email Address!");
        }
        else if (password.equals("")||confirm_password.equals(""))
        {
            textView_error.setText("Please Enter Passwords!");
        }else if (password.length()<6){
            textView_error.setText("Passwords Should Contain at Least 6 Characters");
        }
        else if (!password.equals(confirm_password)){
            textView_error.setText("Passwords Should Match");
        }
        else if(!isCorrectPassword(password)){
            textView_error.setText("Password Should Contain Both Letter and Number!");
        }else if(!checkBox_conditions.isChecked()){
            textView_error.setText("Please Agree the Terms and Conditions!");
        }
        else{
            final String finalUrl = String.format(registerUrl,name,email,password);
            register(finalUrl);
        }

    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_register, menu);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void register(final String Url){

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = ProgressDialog.show(RegisterActivity.this, "Loading...", "Registering......");

            }

            @Override
            protected Void doInBackground(Void... params) {

                userPopulator = new UserPopulator();
                registerOutcome = userPopulator.register(Url);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                //     System.out.println(u.getStatus());
                if (registerOutcome.equals("0")){
                    textView_error.setText("Register Unsuccessful");
                }else if (registerOutcome.equals("-1")){
                    textView_error.setText("Your email address is existing in the system, Please Login using your email!");
                }else {
                    editSharePreference(registerOutcome);
                    Toast.makeText(RegisterActivity.this,"Register Successfully! Enjoy Your Shopping!",Toast.LENGTH_SHORT).show();
                    pd.dismiss();
                    finish();
                }
            }

        }.execute();

    }


    private void editSharePreference(String userID){
        sharedPreferences =RegisterActivity.this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putString("userID",userID);
        editor.putString("userName",editText_name.getText().toString());
        editor.commit();
    }

    private boolean isEmail(String email) {
        String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    private boolean isCorrectPassword(String password) {
        boolean isDigit = false;
        boolean isLetter = false;
        for(int i=0 ; i<password.length() ; i++) {
            if (Character.isDigit(password.charAt(i))) {
                isDigit = true;
                break;
            }
        }

            for(int i=0 ; i<password.length() ; i++) {
                if (Character.isLetter(password.charAt(i))) {
                    isLetter = true;
                    break;
                }
            }

        if (isDigit==true && isLetter ==true){
            return true;
        }
        else{
            return false;
        }

    }

    @Override
    public void onNetChange() {

        if (NetUtil.getNetworkState(this) != NetUtil.NETWORN_NONE) {
            imageview.setVisibility(View.INVISIBLE);
        }

    }


}
