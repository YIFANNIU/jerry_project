package com.example.eric_koh.ginservices.Activities;

import com.example.eric_koh.ginservices.NetWork.NetUtil;

/**
 * Created by Eric_Koh on 8/4/15.
 */



public class Application extends android.app.Application {
    private static Application mApplication;
    public static int mNetWorkState;

    public static synchronized Application getInstance() {
        return mApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mApplication = this;
        initData();
    }



    public void initData() {
        mNetWorkState = NetUtil.getNetworkState(this);
    }
}
