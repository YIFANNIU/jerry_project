package com.example.eric_koh.ginservices.Activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.eric_koh.ginservices.R;
import android.view.MenuInflater;
public class MyAccountMainActivity extends ActionBarActivity {

    private SharedPreferences sharedPreferences;
    private String storedId;
    private Menu menuTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account_main);
        sharedPreferences =this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_my_account_main, menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_my_account_main, menu);
        menuTitle=menu;
        setTitle();

        return super.onCreateOptionsMenu(menu);



    }

    @Override
    public void onResume() {
        Log.i("tttttttttttt", "jjjjjjjjj");
        super.onResume();
        if(menuTitle!=null){
            setTitle();
        }

    }

    public void setTitle() {

        storedId = sharedPreferences.getString("userID", "0");
        System.out.println("111111:" + storedId);
        System.out.println("login onresume");
        if (storedId.equals("0")) {

            menuTitle.getItem(0).setTitle(storedId);

        } else {

            menuTitle.getItem(0).setTitle(storedId);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
