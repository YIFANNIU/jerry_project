package com.example.eric_koh.ginservices.Tools;

/**
 * Created by linkupcrm on 7/4/15.
 */
public class UrlManager {

    public static String dbName = "GinServices_ERP";
    public static String appID = "117";
    public static String isMobile = "1";

    public static String server = "9";

    public static String apiBaseUrl =String.format("http://webservice%s.linkupcrm.com/GetUser.svc/",server);
    public static String websiteBaseUrl =String.format("http://webservice%s.linkupcrm.com/",server);
    public static String webViewBaseUrl =String.format("http://ginservices%s.linkupcrm.com/",server);


    //webViewUrl
    public static String checkOutUrl = webViewBaseUrl +"MobileWebUI_OnlineStore/Product_Checkout.aspx?app=177&UserID=%s&m=1";
    public static String myaccountUrl = webViewBaseUrl +"MobileWebUI_OnlineStore/User_Profile.aspx?app=177&UserID=%s&m=1";

    public static String contactUrl = webViewBaseUrl +"Content_Widget/Page_Enquiry.aspx?app=177&UserID=%s&m=1";
    public static String productUrl = webViewBaseUrl +"MobileWebUI_OnlineStore/Product_List.aspx?app=177&UserID=0&m=1";
    public static String homeUrl=websiteBaseUrl+"AspxFiles/HomePage.aspx?_dbName="+dbName+"&WebUIID=1";


    //apiUrl
    public static String registerApiUrl = apiBaseUrl+"OnlineShoppingRegister?_dbName="+dbName+"&_fullName=%s&_emailAddress=%s&_password=%s&_agreement=1";
    public static String forgetPasswordApiUrl = apiBaseUrl+"GetUserInfoByEmail?_dbName="+dbName+"&_emailAddress=%s";
    public static String loginApiUrl = apiBaseUrl+"GetUser/%s,%s,GinServices_ERP";




}
