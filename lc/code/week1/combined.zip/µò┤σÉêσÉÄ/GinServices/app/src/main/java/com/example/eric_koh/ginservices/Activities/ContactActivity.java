package com.example.eric_koh.ginservices.Activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.R;

/**
 * Created by Eric_Koh on 6/4/15.
 */
public class ContactActivity extends ActionBarActivity {

    private WebView webView;
    private ImageView imageview;
    // flag for Internet connection status
    Boolean isInternetPresent = false;

    // Connection detector class
    ConnectionDetector cd;

    ProgressDialog dialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        webView = (WebView) findViewById(R.id.webView1);
        imageview = (ImageView) findViewById(R.id.internetInfo);
        loadurl();

    }


    @Override
    protected void onResume(){
        super.onResume();
        Log.i("hh11111", "jajjajajaj");
        loadurl();
    }
    public void loadurl(){

        cd = new ConnectionDetector(getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();

        // check for Internet status
        if (isInternetPresent) {
            // Internet Connection is Present
            // make HTTP requests

            webView.getSettings().setJavaScriptEnabled(true);//设置使用够执行JS脚本
            webView.getSettings().setBuiltInZoomControls(true);//设置使支持缩放
//      webView.getSettings().setDefaultFontSize(5);

            webView.loadUrl("http://ginservices9.linkupcrm.com/Content_Widget/Page_Enquiry.aspx?app=177&UserID=0&m=1");
            webView.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    // TODO Auto-generated method stub
                    webView.loadUrl(url);
                    return true;
                }
                @Override
                public void onReceivedError(WebView view, int errorCode,
                                            String description, String failingUrl) {
                    // super.onReceivedError(view, errorCode, description, failingUrl);
                    showAlertDialog(ContactActivity.this, "No Internet Connection",
                            "You don't have internet connection.", false);
                    imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));

                }



            });


        } else {
            // Internet connection is not present
            // Ask user to connect to Internet

            imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));

        }

    }

    @Override   //默认点回退键，会退出Activity，需监听按键操作，使回退在WebView内发生
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void showAlertDialog(Context context, String title, String message, Boolean status) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();

        // Setting Dialog Title
        alertDialog.setTitle(title);

        // Setting Dialog Message
        alertDialog.setMessage(message);

        // Setting alert dialog icon
        //  alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

        // Setting OK Button
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }
}



