package com.example.eric_koh.ginservices.Activities;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.eric_koh.ginservices.Models.User;
import com.example.eric_koh.ginservices.Populator.UserPopulator;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.UrlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginFragment extends Fragment {


    private View v;

    private User u;
    private UserPopulator userPopulator;

    private EditText editText_loginEmail;
    private EditText editText_loginPassword;
    private TextView textView_loginError;
    private EditText editText_forgetPasswordEmail;
    private Button btn_login;
    private Button btn_Register;
    private Button btn_submitForgetPasswordEmail;
    private TextView textView_ForgotPasswordError;

    private String loginUrl = UrlManager.apiBaseUrl+"GetUser/%s,%s,GinServices_ERP";

    public  LoginFragment(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_login, container, false);
        findView();
        return v;
    }


    private void findView(){
        btn_login =(Button)v.findViewById(R.id.btn_login);
        editText_loginEmail = (EditText)v.findViewById(R.id.editText_email);
        editText_loginPassword  = (EditText)v.findViewById(R.id.editText_password);
        textView_loginError = (TextView)v.findViewById(R.id.textView_login_error);
        textView_ForgotPasswordError = (TextView)v.findViewById(R.id.textView_forgetpassword_error);
        editText_forgetPasswordEmail = (EditText)v.findViewById(R.id.editText_forgetPasswordEmailAddress);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("hehe");
                loginValidation();

              //  displayCheckOutPage("aheh");
            }
        });
    }

    private void loginValidation(){

        if("".equals(editText_loginEmail.getText().toString().replace(" ", ""))){
            textView_loginError.setText("Please Enter Email Address");
        }else if (!isEmail(editText_loginEmail.getText().toString())){
            textView_loginError.setText("Please Check Your Email Format ");
        }else if ("".equals(editText_loginPassword.getText().toString().replace(" ",""))){
            textView_loginError.setText("Please Enter Your Password");
        }else {
            getUser();
        }


    }

    private boolean isEmail(String email) {
        String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    private void getUser(){
        String loginEmail = editText_loginEmail.getText().toString();
        String loginPassword = editText_loginPassword.getText().toString();
        final String finalUrl = String.format(loginUrl,loginEmail,loginPassword);
        System.out.println(finalUrl);

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {

                userPopulator = new UserPopulator();
                u = userPopulator.getUser(finalUrl);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                System.out.println(u.getStatus());
            }

        }.execute();
    }

    private void displayCheckOutPage(String userID) {
        final String TAG = "DETAILS_FRAG";
        FragmentManager fm = getFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        Fragment frag = new CheckOutFragment();
        Bundle args = new Bundle();
        args.putString("userID", userID);
        frag.setArguments(args);
//        if (fm.findFragmentByTag(TAG) == null)
//            trans.add(R.id.checkOutFrame, frag, TAG);
//        else
        trans.replace(R.id.checkOutFrame, frag, TAG);
        trans.commit();
    }


}