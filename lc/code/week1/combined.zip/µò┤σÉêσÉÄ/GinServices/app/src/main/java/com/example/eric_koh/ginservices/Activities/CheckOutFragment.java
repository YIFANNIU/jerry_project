package com.example.eric_koh.ginservices.Activities;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.eric_koh.ginservices.R;

public class CheckOutFragment extends Fragment  {


    public CheckOutFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("onCreate");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_check_out, container, false);
        System.out.println("onCreateView");


        return(view);
    }




//    protected void display(String details) {
//        final String TAG = "DETAILS_FRAG";
//        FragmentManager fm = getFragmentManager();
//        FragmentTransaction trans = fm.beginTransaction();
//
//        Fragment frag = new Details();
//        Bundle args = new Bundle();
//        args.putString("customerdetails", details);
//        frag.setArguments(args);
//
//        if (fm.findFragmentByTag(TAG) == null)
//            trans.add(R.id.detailsframe, frag, TAG);
//        else
//            trans.replace(R.id.detailsframe, frag, TAG);
//
//        trans.commit();
//    }

}