package com.example.eric_koh.ginservices.Tools;

/**
 * Created by linkupcrm on 7/4/15.
 */
public class UrlManager {
    public static String server = "9";

    public static String apiBaseUrl =String.format("http://webservice%s.linkupcrm.com/GetUser.svc/",server);
    public static String websiteBaseUrl =String.format("http://webservice%s.linkupcrm.com/",server);
    public static String webViewBaseUrl =String.format("http://ginservices%s.linkupcrm.com/",server);


}
