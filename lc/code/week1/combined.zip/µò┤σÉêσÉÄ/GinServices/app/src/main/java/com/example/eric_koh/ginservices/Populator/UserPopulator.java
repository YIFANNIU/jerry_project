package com.example.eric_koh.ginservices.Populator;

import android.util.Log;

import com.example.eric_koh.ginservices.Models.User;
import com.example.eric_koh.ginservices.Tools.JSONParser;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by JiawenHuang on 7/4/15.
 */
public class UserPopulator {

    public User getUser(String url){

        User u = null;

        JSONObject result = JSONParser.getJSONFromUrl(url);


        try {
            JSONArray ja = result.getJSONArray("GetUserResult");
            if (ja.length()==0){
                return null;

            }else {
                JSONObject obj = ja.getJSONObject(0);
                u = new User();
                u.setStatus(obj.getString("_StatusID"));
                u.setUserID(obj.getString("m_UserID"));
            }


        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }


        return u;
    }

}
