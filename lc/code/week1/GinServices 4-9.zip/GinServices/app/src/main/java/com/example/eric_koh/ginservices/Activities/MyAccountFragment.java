package com.example.eric_koh.ginservices.Activities;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.UrlManager;

public class MyAccountFragment extends Fragment  {

    private View view;
    private SharedPreferences sharedPreferences;
    private String storedId;
    private WebView webView;
    private ImageView imageview;
    private String checkOutUrl = UrlManager.checkOurUrl;
    // private checkOut
    // flag for Internet connection status
    public Boolean isInternetPresent = false;


    public MyAccountFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences =this.getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        System.out.println("onCreate");
    }

    @Override
    public void onResume() {
        super.onResume();
        storedId = sharedPreferences.getString("userID", "0");
        System.out.println("========>StoredID:"+storedId);
        System.out.println("onresume");
        if (storedId.equals("0")){
            displayLoginPage();
            getActivity().getFragmentManager().beginTransaction().remove(this).commit();
        }else {
            System.out.println("going to display checkoutpage");
            displayCheckOutPage(storedId);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_check_out, container, false);
        System.out.println("onCreateView");
        return(view);
    }

    protected void displayLoginPage() {
        final String TAG = "LOGIN_FRAG";
        FragmentManager fm = getFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();
        Fragment frag = new LoginFragment();
        Bundle args = new Bundle();
        args.putString("from", "MyAccount");
        frag.setArguments(args);
//        if (fm.findFragmentByTag(TAG) == null)
//            trans.add(R.id.checkOutFrame, frag, TAG);
//        else
        trans.replace(R.id.checkOutFrame, frag, TAG);
        trans.commit();
    }

    public void  displayCheckOutPage(String storedId){

        webView = (WebView)view.findViewById(R.id.webView1);
        webView.getSettings().setJavaScriptEnabled(true);//enable java script
        webView.getSettings().setBuiltInZoomControls(true);//support zoom in/out
//      webView.getSettings().setDefaultFontSize(5);

    //    webView.loadUrl(String.format(checkOutUrl,storedId));
        webView.loadUrl("http://www.baidu.com");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                view.loadUrl(url);// 使用当前WebView处理跳转
                return true;//true表示此事件在此处被处理，不需要再广播
            }

            @Override   //转向错误时的处理
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                // TODO Auto-generated method stub
                // Toast.makeText(CheckOutFragment.this, "Oh no! " + description, Toast.LENGTH_SHORT).show();
            }
        });


    }





}