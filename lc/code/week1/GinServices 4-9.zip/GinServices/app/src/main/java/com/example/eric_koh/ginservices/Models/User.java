package com.example.eric_koh.ginservices.Models;

/**
 * Created by JiawenHuang on 7/4/15.
 */
public class User {
    private String status;
    private String userID;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}

