package com.example.eric_koh.ginservices.Tools;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.eric_koh.ginservices.Models.User;

/**
 * Created by JiawenHuang on 13/4/15.
 */
public class SharedPreferenceManager {

    public static final String FILE_NAME = "userInfo";


    public static User getUser(Context context) {
        SharedPreferences sp = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);

        if (sp.getString("userID","0").equals("0")){
            return null;
        }else {
            User u = new User();
            u.setUserID(sp.getString("userID", "0"));
            u.setUserName(sp.getString("userName",""));
            u.setUserEmail(sp.getString("userEmail",""));
            return u;
        }
    }

    public static void updateUser(Context context,User user) {
        SharedPreferences sp = context.getSharedPreferences(FILE_NAME,
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("userID", user.getUserID());
        editor.putString("userName", user.getUserName()+" ");
        editor.putString("userEmail",user.getUserEmail());
        editor.commit();

    }
}
