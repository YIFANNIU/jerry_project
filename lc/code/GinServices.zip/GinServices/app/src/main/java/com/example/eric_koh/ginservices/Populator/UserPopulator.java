package com.example.eric_koh.ginservices.Populator;

import android.util.Log;

import com.example.eric_koh.ginservices.Models.User;
import com.example.eric_koh.ginservices.Tools.JSONParser;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by JiawenHuang on 7/4/15.
 */
public class UserPopulator {

    public User getUser(String url){

        User u = null;

        JSONObject result = JSONParser.getJSONFromUrl(url);
        try {
            JSONArray ja = result.getJSONArray("GetUserResult");
            System.out.println(ja.length());
            if (ja.length()== 0){
                System.out.print("PPPPPP0");
                return u;
            }else {
                JSONObject obj = ja.getJSONObject(0);
                u = new User();
                u.setStatus(obj.getString("_StatusID"));
                u.setUserID(obj.getString("m_UserID"));
                u.setUserName(obj.getString("m_fullname"));
                u.setUserEmail(obj.getString("m_Email"));
            }


        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }

        return u;
    }


    public User forgetPassword(String url){

        User u = null;

        JSONObject result = JSONParser.getJSONFromUrl(url);
        try {
            JSONArray ja = result.getJSONArray("GetUserInfoByEmailResult");
            System.out.println(ja.length());
            if (ja.length()== 0){
                System.out.print("PPPPPP0");
                return u;
            }else {
                JSONObject obj = ja.getJSONObject(0);
                u = new User();
                u.setStatus(obj.getString("_StatusID"));
                u.setUserID(obj.getString("m_UserID"));
            }


        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }

        return u;
    }


    public String register(String url){

        String outcome = "0";

        JSONObject result = JSONParser.getJSONFromUrl(url);
        try {
            outcome = result.getString("OnlineShoppingRegisterResult");
        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }
        System.out.println("}}}}}}}->"+outcome);
        return outcome;
    }


    public User getUserByID(String url){

        User u = null;

        JSONObject result = JSONParser.getJSONFromUrl(url);
        try {
            JSONArray ja = result.getJSONArray("GetUserInfoByUserIDResult");
            System.out.println(ja.length());
            if (ja.length()== 0){
                System.out.print("PPPPPP0");
                return u;
            }else {
                JSONObject obj = ja.getJSONObject(0);
                u = new User();
                u.setStatus(obj.getString("_StatusID"));
                u.setUserID(obj.getString("m_UserID"));
                u.setUserName(obj.getString("m_fullname"));
                u.setUserEmail(obj.getString("m_Email"));
            }


        } catch (Exception e) {
            Log.e("list", "JSONArray error");
        }

        return u;
    }

}
