package com.example.eric_koh.ginservices.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.webkit.WebChromeClient;

import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver;
import com.example.eric_koh.ginservices.NetWork.NetUtil;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver.netEventHandler;
import com.example.eric_koh.ginservices.Tools.UrlManager;

public class HomeActivity extends ActionBarActivity implements netEventHandler{
    final Activity context = this;
    private WebView webView;
    private ImageView imageview;
    public Boolean isInternetPresent = false;
    private String homeUrl = UrlManager.homeUrl;
    ConnectionDetector cd;
    private SharedPreferences sharedPreferences;
    private String storedId;
    private Menu menuTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        requestWindowFeature(Window.FEATURE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        NetBroadcastReceiver.mListeners.add(this);
        webView = (WebView) findViewById(R.id.webView1);
        imageview=(ImageView)findViewById(R.id.internetInfo);
        loadurl();
        sharedPreferences =this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.menu_my_account_main, menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_my_account_main, menu);
        menuTitle=menu;
        setTitle();

        return super.onCreateOptionsMenu(menu);



    }

    @Override
    public void onResume() {
        Log.i("tttttttttttt", "jjjjjjjjj");
        super.onResume();
        if(menuTitle!=null){
            setTitle();
        }

    }

    public void setTitle() {

        storedId = sharedPreferences.getString("userName", "");
        System.out.println("111111:" + storedId);
        System.out.println("login onresume");
        if (storedId.equals("")) {

            menuTitle.getItem(0).setTitle(storedId);

        } else {

            menuTitle.getItem(0).setTitle(storedId);
        }
    }




    public void loadurl(){

        cd = new ConnectionDetector(getApplicationContext());
        isInternetPresent = cd.isConnectingToInternet();

        if (isInternetPresent) {

            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setBuiltInZoomControls(true);
            webView.getSettings().setUseWideViewPort(false);
            webView.getSettings().setLoadWithOverviewMode(false);
            webView.getSettings().setDisplayZoomControls(false);
            if(imageview.getDrawable()!=null){
                imageview.setVisibility(View.INVISIBLE);

            }
            webView.setWebChromeClient(new WebChromeClient() {
                public void onProgressChanged(WebView view, int progress) {

                    context.setProgress(progress * 100);
                    Log.i("kkkkkkkkkk","hahhahahahha");
                }
            });

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    // TODO Auto-generated method stub
                    webView.loadUrl(url);
                    return true;
                }

                @Override
                public void onReceivedError(WebView view, int errorCode,
                                            String description, String failingUrl) {
                    super.onReceivedError(view, errorCode, description, failingUrl);
                    //String data = "Page NO FOUND！";
                    //view.loadUrl("javascript:document.body.innerHTML=\"" + data + "\"");

                    //view.clearView();
                    //imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));
                    //view.clearView();
                    String str = "file:///android_asset/nointernet.png";
                    webView.getSettings().setUseWideViewPort(true);
                    webView.getSettings().setLoadWithOverviewMode(true);
                    webView.loadUrl(str);
                    Log.i("testtest test ", "hhhhhhh");

                }
            });
            webView.loadUrl(homeUrl);

        } else {
            webView.clearView();
            imageview.setVisibility(View.VISIBLE);
            imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));

        }

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public void onNetChange() {
        // TODO Auto-generated method stub
        if (NetUtil.getNetworkState(this) == NetUtil.NETWORN_NONE) {
            loadurl();
            Log.i("11111111","jjjjj");
        }else {
            loadurl();
            Log.i("22222222","jjjjj");
        }
    }

}