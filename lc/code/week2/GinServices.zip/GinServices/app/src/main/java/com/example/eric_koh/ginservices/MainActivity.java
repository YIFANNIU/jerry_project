package com.example.eric_koh.ginservices;

import java.util.ArrayList;
import java.util.List;

import android.app.TabActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;
import android.content.Intent;

import com.example.eric_koh.ginservices.Activities.CheckOutMainActivity;
import com.example.eric_koh.ginservices.Activities.ContactActivity;
import com.example.eric_koh.ginservices.Activities.HomeActivity;
import com.example.eric_koh.ginservices.Activities.MyAccountMainActivity;
import com.example.eric_koh.ginservices.Activities.ProductActivity;
import com.example.eric_koh.ginservices.Activities.RegisterActivity;

public class MainActivity extends TabActivity implements OnTabChangeListener {

    private int mCurSelectTabIndex = 0;

    private final int INIT_SELECT = 0;

    private final int DELAY_TIME = 500;
    private TabHost mTabHost;

    private List<ImageView> imageList = new ArrayList<ImageView>();
    private List<TextView> textViews = new ArrayList<TextView>();

    private int textOriginalColor = R.color.material_blue_grey_800;
    private int textOnchargedColor = R.color.TabOnSelected;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTabHost = getTabHost();

        Intent in1=new Intent(this, HomeActivity.class);
        Intent in2=new Intent(this, ProductActivity.class);
        Intent in3=new Intent(this, CheckOutMainActivity.class);
        Intent in4=new Intent(this,MyAccountMainActivity.class);
        Intent in5=new Intent(this, ContactActivity.class);

        mTabHost.addTab(mTabHost.newTabSpec("tab_1").setIndicator(composeLayout("Home", R.drawable.home1_2)).setContent(in1));
        mTabHost.addTab(mTabHost.newTabSpec("tab_2").setIndicator(composeLayout("Product", R.drawable.shop2)).setContent(in2));
        mTabHost.addTab(mTabHost.newTabSpec("tab_3").setIndicator(composeLayout("Check Out", R.drawable.checkout3)).setContent(in3));
        mTabHost.addTab(mTabHost.newTabSpec("tab_4").setIndicator(composeLayout("My Account", R.drawable.myaccount4)).setContent(in4));
        mTabHost.addTab(mTabHost.newTabSpec("tab_5").setIndicator(composeLayout("Contact Us", R.drawable.contactus5)).setContent(in5));

        mTabHost.setBackgroundColor(Color.WHITE);

        mTabHost.setCurrentTab(0);
        textViews.get(0).setTextColor(getResources().getColor(textOnchargedColor));


        mTabHost.setOnTabChangedListener(this);

        initCurSelectTab();
    }

    private Handler initSelectTabHandle = new Handler () {
        public void handleMessage (Message msg) {
            switch (msg.what) {
                case INIT_SELECT:
                    moveTopSelect(INIT_SELECT);
                    break;
                default:
                    break;
            }
            super.handleMessage(msg);
        }
    };


    public void initCurSelectTab(){

        Message msg = new Message();
        msg.what = INIT_SELECT;
        initSelectTabHandle.sendMessageDelayed(msg, DELAY_TIME);

    }



    public void onTabChanged(String tabId) {

        imageList.get(0).setImageDrawable(getResources().getDrawable(R.drawable.home1));
        imageList.get(1).setImageDrawable(getResources().getDrawable(R.drawable.shop2));
        imageList.get(2).setImageDrawable(getResources().getDrawable(R.drawable.checkout3));
        imageList.get(3).setImageDrawable(getResources().getDrawable(R.drawable.myaccount4));
        imageList.get(4).setImageDrawable(getResources().getDrawable(R.drawable.contactus5));

        textViews.get(0).setTextColor(getResources().getColor(textOriginalColor));
        textViews.get(1).setTextColor(getResources().getColor(textOriginalColor));
        textViews.get(2).setTextColor(getResources().getColor(textOriginalColor));
        textViews.get(3).setTextColor(getResources().getColor(textOriginalColor));
        textViews.get(4).setTextColor(getResources().getColor(textOriginalColor));


        if (tabId.equalsIgnoreCase("tab_1")) {
            imageList.get(0).setImageDrawable(getResources().getDrawable(R.drawable.home1_2));
            textViews.get(0).setTextColor(getResources().getColor(textOnchargedColor));

            moveTopSelect(0);
        } else if (tabId.equalsIgnoreCase("tab_2")) {
            imageList.get(1).setImageDrawable(getResources().getDrawable(R.drawable.shop2_2));
            textViews.get(1).setTextColor(getResources().getColor(textOnchargedColor));
            moveTopSelect(1);
        } else if (tabId.equalsIgnoreCase("tab_3")) {
            imageList.get(2).setImageDrawable(getResources().getDrawable(R.drawable.checkout3_2));
            textViews.get(2).setTextColor(getResources().getColor(textOnchargedColor));
            moveTopSelect(2);
        }else if (tabId.equalsIgnoreCase("tab_4")) {
            imageList.get(3).setImageDrawable(getResources().getDrawable(R.drawable.myaccount4_2));
            textViews.get(3).setTextColor(getResources().getColor(textOnchargedColor));
            moveTopSelect(3);
        }else if (tabId.equalsIgnoreCase("tab_5")) {
            imageList.get(4).setImageDrawable(getResources().getDrawable(R.drawable.contactus5_2));
            textViews.get(4).setTextColor(getResources().getColor(textOnchargedColor));
            moveTopSelect(4);
        }
    }


    public void moveTopSelect(int selectIndex) {
        View topSelect = (View) findViewById(R.id.tab_top_select);


        int startMid = ((View) getTabWidget().getChildAt(mCurSelectTabIndex)).getLeft() + ((View) getTabWidget().getChildAt(mCurSelectTabIndex)).getWidth() / 2;

        int startLeft = startMid - topSelect.getWidth() / 2;


        int endMid = ((View) getTabWidget().getChildAt(selectIndex)).getLeft() + ((View) getTabWidget().getChildAt(selectIndex)).getWidth() / 2;

        int endLeft = endMid - topSelect.getWidth() / 2;

        TranslateAnimation animation = new TranslateAnimation(startLeft, endLeft - topSelect.getLeft(), 0, 0);
        animation.setDuration(200);
        animation.setFillAfter(true);
        topSelect.bringToFront();
        topSelect.startAnimation(animation);


        mCurSelectTabIndex = selectIndex;

        Log.i("fs", "endMid  " + endMid + "  startLeft  " + startLeft + "  endLeft" + (endLeft - topSelect.getLeft()));
    }


    public View composeLayout(String s, int i) {

        LinearLayout layout = new LinearLayout(this);

        layout.setOrientation(LinearLayout.VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setMaxHeight(65);
        iv.setMaxHeight(65);
        imageList.add(iv);
        iv.setImageResource(i);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 5, 0, 0);
        layout.addView(iv, lp);
        // 定义TextView
        TextView tv = new TextView(this);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setText(s);
        tv.setTextColor(getResources().getColor(R.color.material_blue_grey_800));
        tv.setTextSize(10);
        textViews.add(tv);
        layout.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return layout;
    }
}