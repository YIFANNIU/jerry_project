package com.example.eric_koh.ginservices.Activities;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eric_koh.ginservices.Models.User;
import com.example.eric_koh.ginservices.NetWork.NetBroadcastReceiver;
import com.example.eric_koh.ginservices.NetWork.NetUtil;
import com.example.eric_koh.ginservices.Populator.UserPopulator;
import com.example.eric_koh.ginservices.R;
import com.example.eric_koh.ginservices.Tools.ConnectionDetector;
import com.example.eric_koh.ginservices.Tools.UrlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginFragment extends Fragment implements NetBroadcastReceiver.netEventHandler {


    private View v;
    private String from;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private User u;
    private String storedId;
    private UserPopulator userPopulator;

    private EditText editText_loginEmail;
    private EditText editText_loginPassword;
    private TextView textView_loginError;
    private EditText editText_forgetPasswordEmail;
    private Button btn_login;
    private Button btn_Register;
    private Button btn_submitForgetPasswordEmail;
    private TextView textView_ForgotPasswordError;




    private String loginUrl = UrlManager.loginApiUrl;
    private String forgetPasswordApiUrl = UrlManager.forgetPasswordApiUrl;

    private ConnectionDetector cd;
    private Boolean isInternetPresent = false;
    private ImageView imageview;

    private ProgressDialog pd;


    public  LoginFragment(){

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences =this.getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        from = getArguments().getString("from");
        System.out.println("oncreate");
    }


    @Override
    public void onResume() {
        super.onResume();
        storedId = sharedPreferences.getString("userID", "0");
        System.out.println("========>StoredID:"+storedId);
        System.out.println("login onresume");
        if (storedId.equals("0")){
            displayLoginPage();
        }else {
           displayCheckOutPage();
            getActivity().getFragmentManager().beginTransaction().remove(LoginFragment.this).commit();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        System.out.println("oncreateview");

        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_login, container, false);
        NetBroadcastReceiver.mListeners.add(this);
        imageview=(ImageView)v.findViewById(R.id.internetInfo);
        cd = new ConnectionDetector(getActivity());

        return v;
    }


    private void displayLoginPage(){
        btn_login =(Button)v.findViewById(R.id.btn_login);
        btn_Register = (Button)v.findViewById(R.id.btn_register);
        btn_submitForgetPasswordEmail = (Button)v.findViewById(R.id.btn_forgetpassword_submit);
        editText_loginEmail = (EditText)v.findViewById(R.id.editText_email);
        editText_loginPassword  = (EditText)v.findViewById(R.id.editText_password);
        textView_loginError = (TextView)v.findViewById(R.id.textView_login_error);
        textView_ForgotPasswordError = (TextView)v.findViewById(R.id.textView_forgetpassword_error);
        editText_forgetPasswordEmail = (EditText)v.findViewById(R.id.editText_forgetPasswordEmailAddress);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if( isInternetPresent = cd.isConnectingToInternet()){
                   loginValidation();
               }else {
                   imageview.setVisibility(View.VISIBLE);
                   imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));
                   System.out.println("Network Problem");
               }

            }
        });

        btn_submitForgetPasswordEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( isInternetPresent = cd.isConnectingToInternet()){
                    forgetPassword();
                }else {
                    imageview.setVisibility(View.VISIBLE);
                    imageview.setImageDrawable(getResources().getDrawable(R.drawable.nointernet));
                    System.out.println("Network Problem");
                }



            }
        });

        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),RegisterActivity.class);
                startActivity(i);
            }
        });
    }

    private void loginValidation(){

        if("".equals(editText_loginEmail.getText().toString().replace(" ", ""))){
            textView_loginError.setText("Please Enter Email Address!");
        }else if (!isEmail(editText_loginEmail.getText().toString())){
            textView_loginError.setText("Please Check Your Email Format!");
        }else if ("".equals(editText_loginPassword.getText().toString().replace(" ",""))){
            textView_loginError.setText("Please Enter Your Password!");
        }else {
            getUser();
        }


    }

    private boolean isEmail(String email) {
        String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    private void getUser(){

        String loginEmail = editText_loginEmail.getText().toString();
        String loginPassword = editText_loginPassword.getText().toString();
        final String finalUrl = String.format(loginUrl, loginEmail, loginPassword);
        System.out.println(finalUrl);

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = ProgressDialog.show(getActivity(), "Loading...", "Validating User Information......");

            }


            @Override
            protected Void doInBackground(Void... params) {

                userPopulator = new UserPopulator();
                u = userPopulator.getUser(finalUrl);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {

                pd.dismiss();
                super.onPostExecute(aVoid);
           //     System.out.println(u.getStatus());
                if (u == null){
                    textView_loginError.setText("Invalid Email or Password!");
                }else if (u.getStatus().equals("8")){
                    editSharePreference(u);
                    NetBroadcastReceiver.mListeners.clear();
                    Toast.makeText(getActivity(),"Login Successfully, Enjoy Your Shopping!",Toast.LENGTH_SHORT).show();
                    displayCheckOutPage();
                getActivity().getFragmentManager().beginTransaction().remove(LoginFragment.this).commit();
                }else {
                    textView_loginError.setText("Your account is not activated. Please contact the system administrator.");
                }
//                displayCheckOutPage(u.getUserID());
            }

        }.execute();
    }

    private void displayCheckOutPage() {
        final String TAG = "LOGIN_FRAG";
        FragmentManager fm = getFragmentManager();
        FragmentTransaction trans = fm.beginTransaction();


        Fragment frag;
        if (from.equals("CheckOut")){
            frag = new CheckOutFragment();
            CheckOutMainActivity c = (CheckOutMainActivity)getActivity();
            c.setName();
        }else {
            MyAccountMainActivity m = (MyAccountMainActivity)getActivity();
            m.setName();
            frag = new MyAccountFragment();

        }


        Bundle args = new Bundle();
      //  args.putString("page", "CheckOut");
        frag.setArguments(args);
//        if (fm.findFragmentByTag(TAG) == null)
//            trans.add(R.id.checkOutFrame, frag, TAG);
//        else
        trans.replace(R.id.checkOutFrame, frag, TAG);
        trans.commit();
    }

    private void editSharePreference(User u){
        editor = sharedPreferences.edit();
        editor.putString("userID", u.getUserID());
        editor.putString("userName",u.getUserName());
        editor.commit();
    }

    private void forgetPassword(){
        String email = editText_forgetPasswordEmail.getText().toString().replace(" ","");
        if (email.equals("")){
            textView_ForgotPasswordError.setText("Please Enter Email Address!");

        }else if (!isEmail(email)){
            textView_ForgotPasswordError.setText("Please Check Your Email Format!");
        }else {
            submitEmail(email);
        }

    }

    private void submitEmail(String email){
        final String finalUrl = String.format(forgetPasswordApiUrl,email);
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = ProgressDialog.show(getActivity(), "Loading...", "Validating User Information......");

            }

            @Override
            protected Void doInBackground(Void... params) {
                userPopulator = new UserPopulator();
                u = userPopulator.forgetPassword(finalUrl);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                pd.dismiss();
                //     System.out.println(u.getStatus());
                if (u == null){
                    textView_ForgotPasswordError.setTextColor(getResources().getColor(R.color.Red));

                    textView_ForgotPasswordError.setText("Email is Not Registered!");
                }else {
                    textView_ForgotPasswordError.setText("Password will be Sent to your Email!");
                    textView_ForgotPasswordError.setTextColor(getResources().getColor(R.color.green));
                }
//
            }
        }.execute();

    }


    @Override
    public void onNetChange() {

        if (NetUtil.getNetworkState(getActivity()) != NetUtil.NETWORN_NONE) {
            imageview.setVisibility(View.INVISIBLE);
        }

    }
}